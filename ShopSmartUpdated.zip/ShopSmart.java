
import java.util.*;

public class ShopSmart {
    static class Product {
        String name;
        double price;

        Product(String name, double price) {
            this.name = name;
            this.price = price;
        }

        public String toString() {
            return name + " - ₹" + price;
        }
    }

    static Map<Integer, Product> storeProducts = new HashMap<>();
    static List<Product> cart = new ArrayList<>();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        populateProducts();

        boolean running = true;

        System.out.println("🛒 Welcome to ShopSmart: Your Digital Grocery Store!");

        while (running) {
            System.out.println("\n--- Main Menu ---");
            System.out.println("1. View Products");
            System.out.println("2. Add to Cart");
            System.out.println("3. View Cart");
            System.out.println("4. Checkout");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    displayProducts();
                    break;
                case 2:
                    addToCart(sc);
                    break;
                case 3:
                    viewCart();
                    break;
                case 4:
                    checkout();
                    running = false;
                    break;
                case 5:
                    running = false;
                    System.out.println("Thank you for shopping at ShopSmart!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }

        sc.close();
    }

    static void populateProducts() {
        storeProducts.put(1, new Product("Apples (1kg)", 100.0));
        storeProducts.put(2, new Product("Milk (1L)", 55.0));
        storeProducts.put(3, new Product("Rice (5kg)", 350.0));
        storeProducts.put(4, new Product("Bread", 40.0));
        storeProducts.put(5, new Product("Eggs (12)", 75.0));
    }

    static void displayProducts() {
        System.out.println("\n--- Available Products ---");
        for (Map.Entry<Integer, Product> entry : storeProducts.entrySet()) {
            System.out.println(entry.getKey() + ". " + entry.getValue());
        }
    }

    static void addToCart(Scanner sc) {
        displayProducts();
        System.out.print("Enter product number to add to cart: ");
        int productId = sc.nextInt();

        if (storeProducts.containsKey(productId)) {
            cart.add(storeProducts.get(productId));
            System.out.println(storeProducts.get(productId).name + " added to cart.");
        } else {
            System.out.println("Invalid product number.");
        }
    }

    static void viewCart() {
        System.out.println("\n--- Your Cart ---");
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty.");
        } else {
            double total = 0;
            for (Product p : cart) {
                System.out.println("- " + p);
                total += p.price;
            }
            System.out.println("Total: ₹" + total);
        }
    }

    static void checkout() {
        viewCart();
        System.out.println("✅ Thank you for your purchase!");
    }
}
